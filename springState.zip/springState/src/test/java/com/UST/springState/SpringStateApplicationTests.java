package com.UST.springState;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringStateApplicationTests {

	@Test
	void contextLoads() {
	}

}
