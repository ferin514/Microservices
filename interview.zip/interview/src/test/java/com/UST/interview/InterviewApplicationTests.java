package com.UST.interview;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InterviewApplicationTests {

	@Test
	void contextLoads() {
	}

}
