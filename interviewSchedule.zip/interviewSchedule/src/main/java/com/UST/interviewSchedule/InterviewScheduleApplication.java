package com.UST.interviewSchedule;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InterviewScheduleApplication {

	public static void main(String[] args) {
		SpringApplication.run(InterviewScheduleApplication.class, args);
	}

}
